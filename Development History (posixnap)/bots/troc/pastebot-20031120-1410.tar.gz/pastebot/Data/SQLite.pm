# $Id: Data.pm,v 1.2 2002/10/15 22:12:34 rcaputo Exp $

# Data management.

package Util::Data;

use strict;
use Exporter;
use Carp qw(croak);
use POE;
use Util::Conf;
use DBI;
use DBD::SQLite;

use vars  qw(@ISA @EXPORT);
@ISA    = qw(Exporter);
@EXPORT = qw( store_paste fetch_paste delete_paste list_paste_ids 
              delete_paste_by_id fetch_paste_channel clear_channel_ignores
              set_ignore clear_ignore get_ignores is_ignored
            );

# sub PASTE_TIME    () { 0 }
# sub PASTE_BODY    () { 1 }
# sub PASTE_SUMMARY () { 2 }
# sub PASTE_ID      () { 3 }
# sub PASTE_NETWORK () { 4 }
# sub PASTE_CHANNEL () { 5 }
# sub PASTE_HOST    () { 6 }
sub SQLITE_FILE   () { "pastes.db" }

#my $id_sequence = 0;
my $exists = -e SQLITE_FILE;
my $dbh = DBI->connect( "dbi:SQLite:dbname=" . SQLITE_FILE,
                        "",
                        "",
                        {AutoCommit => 1}) or die $DBI::errstr;
if(!$exists) {
    $dbh->do(q{
        CREATE TABLE 'Pastes'
        (
            ID INTEGER PRIMARY KEY,
            Time,
            Body,
            Summary,
            Paster,
            Network,
            Channel,
            Host
        )
    }) or die $dbh->errstr;
}


DESTROY {
    $dbh->disconnect();
}

my %ignores; # $ignores{$ircnet}{lc $channel} = [ mask, mask, ... ];

# return a list of all paste ids
sub list_paste_ids {
    my $sth = $dbh->prepare("SELCT ID FROM Pastes") or die $dbh->errstr;
    $sth->execute() or die $dbh->errstr;
    return map {$_->{ID}} @{$sth->fetchall_arrayref({})};

}

# remove pastes that are too old (if applicable)
# sub check_paste_count {
#    my @names = get_names_by_type('pastes');
#    return unless @names;
#    my %conf = get_items_by_name($names[0]);
#    return unless %conf && $conf{'count'};
#    return if (scalar keys %paste_cache < $conf{'count'});
#    my $oldest = time;
#    for (keys %paste_cache) {
#       $oldest = $_ if $paste_cache{$_}->[PASTE_TIME] < $oldest;
#    }
#    delete $paste_cache{$oldest};
# }

# Save paste, returning an ID.

sub store_paste {
      # first argument was originally named $id, I don't know why,
      # it's called by sending in a $nick variable which
      # contains something similar to "nickname at address"
      # I've renamed this argument and table-column to "Paster"
    my ($paster, $summary, $paste, $ircnet, $channel, $ipaddress) = @_;
#   check_paste_count();
    my $sth = $dbh->prepare(q{
        INSERT INTO Pastes(
            Paster, Summary, Body, Network, Channel, Host, Time
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?
        )
    }) or die $dbh->errstr;
    $sth->execute($paster, $summary, $paste, $ircnet, $channel, $ipaddress, time)
     or die $dbh->errstr;
    return $dbh->func('last_insert_rowid');
}

# Fetch paste by ID.

sub fetch_paste {
    my($id) = @_;
    my $sth = $dbh->prepare(
        "SELECT Paster, Summary, Body FROM Pastes WHERE ID = ?"
    ) or die $dbh->errstr;
    $sth->execute($id) or die $dbh->errstr;
    return $sth->fetchrow_array();
}

# Fetch the channel a paste was meant for.

sub fetch_paste_channel {
    my($id) = @_;
    my $sth = $dbh->prepare(
        "SELECT Channel FROM Pastes WHERE ID = ?"
    ) or die $dbh->errstr;
    $sth->execute($id) or die $dbh->errstr;
    return $sth->fetchrow_arrayref()->[0];
}

sub delete_paste_by_id {
    my($id) = @_;
    my $sth = $dbh->prepare(
        "DELETE FROM Pastes WHERE ID = ?"
    ) or die $dbh->errstr;
    $sth->execute($id) or die $dbh->errstr;
}

# Delete a possibly sensitive or offensive paste.

sub delete_paste {
    my ($ircnet, $channel, $id, $bywho) = @_;
    my $sth = $dbh->prepare(q{
        UPDATE Pastes SET
        Body = ? WHERE
        ID = ? AND
        Network = ? AND
        Channel = ?
    }) or die $dbh->errstr;
    $sth->execute("Deleted by $bywho", $id, $ircnet, $channel) or die $dbh->errstr;
}

# manage channel/IRC network based ignores of http requestors

sub _convert_mask {
  my $mask = shift;

  $mask =~ s/\./\\./g;
  $mask =~ s/\*/\\d+/g;

  $mask;
}

sub is_ignored {
  my ($ircnet, $channel, $host) = @_;

  $ignores{$ircnet}{lc $channel} && @{$ignores{$ircnet}{lc $channel}}
    or return;

  for my $mask (@{$ignores{$ircnet}{lc $channel}}) {
    $host =~ /^$mask$/ and return 1;
  }

  return;
}

sub set_ignore {
  my ($ircnet, $channel, $mask) = @_;

  $mask = _convert_mask($mask);

  # remove any existing mask - so it's not fast
  @{$ignores{$ircnet}{lc $channel}} = 
    grep $_ ne $mask, @{$ignores{$ircnet}{lc $channel}};
  push @{$ignores{$ircnet}{lc $channel}}, $mask;
}

sub clear_ignore {
  my ($ircnet, $channel, $mask) = @_;

  $mask = _convert_mask($mask);

  @{$ignores{$ircnet}{lc $channel}} = 
    grep $_ ne $mask, @{$ignores{$ircnet}{lc $channel}};
}

sub get_ignores {
  my ($ircnet, $channel) = @_;

  $ignores{$ircnet}{lc $channel} or return;

  my @masks = @{$ignores{$ircnet}{lc $channel}};

  for (@masks) {
    s/\\d\+/*/g;
    s/\\././g;
  }

  @masks;
}

sub clear_channel_ignores {
  my ($ircnet, $channel) = @_;

  $ignores{$ircnet}{lc $channel} = [];
}

# Commented out because it involved purging, which is no longer an issue

# my @pastes = get_names_by_type('pastes');
# if (@pastes) {
#    my %conf = get_items_by_name($pastes[0]);
#    if ($conf{'check'} && $conf{'expire'}) {
#       POE::Session->new(
#          _start => sub { $_[KERNEL]->delay( ticks => $conf{'check'} );  },
#          ticks => sub { 
#             for (keys %paste_cache) {
#                next unless (time - $paste_cache{$_}->[PASTE_TIME]) > $conf{'expire'};
#                delete $paste_cache{$_};
#             }
#             $_[KERNEL]->delay( ticks => $conf{'check'} );  
#          },
#       );
#    }
# }
### End.

1;
