# $Id: IRC.pm,v 1.3 2002/10/18 02:44:48 rcaputo Exp $

# Rocco's IRC bot stuff.

package Client::IRC;

use strict;

use POE::Session;
use POE::Component::IRC;

use Util::Database;
use Util::Conf;

my %ignored =
  ( purl      => 1,
    nopaste   => 1,
    pastebot  => 1,
    eatpaste  => 1,
    dipsy     => 1,
    laotse    => 1,
    "perl-fu" => 1,
  );

my %helptext =
  ( help => <<EOS,
There is no help yet.
EOS
  );

# easy to enter, make it suitable to send
for my $key (keys %helptext) {
  $helptext{$key} =~ tr/\n /  /s;
  $helptext{$key} =~ s/\s+$//;
}

# Used to cache verbs!
my %verbs;

init_bot();

#------------------------------------------------------------------------------
# Spawn the IRC session(s).

foreach my $server (get_names_by_type('irc')) {
  my %conf = get_items_by_name($server);

  POE::Component::IRC->new($server);

  POE::Session->create
    ( inline_states =>
      { _start => sub {
          my ($kernel, $heap, $session) = @_[KERNEL, HEAP, SESSION];

          $kernel->alias_set( "irc_client_$server" );
          $kernel->post( $server => register => 'all' );

          $heap->{server_index} = 0;

          # Keep-alive timer.
          $kernel->delay( autoping => 300 );

          $kernel->yield( 'connect' );
        },

        autoping => sub {
          my ($kernel, $heap) = @_[KERNEL, HEAP];
          $kernel->post( $server => userhost => $conf{nick} )
            unless $heap->{seen_traffic};
          $heap->{seen_traffic} = 0;
          $kernel->delay( autoping => 300 );
        },

        connect => sub {
          my ($kernel, $heap) = @_[KERNEL, HEAP];

          $kernel->post( $server => connect =>
                         { Debug     => 0,
                           Nick      => $conf{nick},
                           Server    => $conf{server}->[$heap->{server_index}],
                           Port      => 6667,
                           Username  => $conf{uname},
                           Ircname   => $conf{iname},
                           LocalAddr => $conf{localaddr},
                         }
                       );

          $heap->{server_index}++;
          $heap->{server_index} = 0
            if $heap->{server_index} >= @{$conf{server}};
        },

        join => sub {
          my ($kernel, $channel) = @_[KERNEL, ARG0];
          if ($channel =~ /^(\S+)\s+(\S+)/) {
            $kernel->post( $server => join => $1, $2 );
          }
          else {
            $kernel->post( $server => join => $channel );
          }
        },

        irc_msg => sub {
          my ($kernel, $heap, $sender, $msg) = @_[KERNEL, HEAP, ARG0, ARG2];

          my ($nick) = $sender =~ /^([^!]+)/;
          print "Message $msg from $nick\n";

          my $response = try_all($msg, $server, "msg", $nick, 1);

          if (defined $response) {
            if (ref($response) eq "ARRAY") {
              foreach (@$response) {
                $kernel->post($server => privmsg => $nick, $_);
              }
            }
            else {
              $kernel->post($server => privmsg => $nick, $response);
            }
          }
        },

        _default => sub {
          my ($state, $event, $args, $heap) = @_[STATE, ARG0, ARG1, HEAP];
          $args ||= [ ];
          print "default $state = $event (@$args)\n";
          $heap->{seen_traffic} = 1;
          return 0;
        },

        irc_001 => sub {
          my ($kernel, $heap) = @_[KERNEL, HEAP];

          if (defined $conf{flags}) {
            $kernel->post( $server => mode => $conf{nick} => $conf{flags} );
          }

          $kernel->post( $server => away => $conf{away} );

          foreach my $channel (@{$conf{channel}}) {
            $kernel->yield( join => $channel );
          }

          $heap->{server_index} = 0;
        },

        irc_ctcp_version => sub {
          my ($kernel, $sender) = @_[KERNEL, ARG0];
          my $who = (split /!/, $sender)[0];
          print "ctcp version from $who\n";
          $kernel->post( $server => ctcpreply => $who, "VERSION $conf{cver}" );
        },

        irc_ctcp_clientinfo => sub {
          my ($kernel, $sender) = @_[KERNEL, ARG0];
          my $who = (split /!/, $sender)[0];
          print "ctcp clientinfo from $who\n";
          $kernel->post( $server => ctcpreply =>
                         $who, "CLIENTINFO $conf{ccinfo}"
                       );
        },

        irc_ctcp_userinfo => sub {
          my ($kernel, $sender) = @_[KERNEL, ARG0];
          my $who = (split /!/, $sender)[0];
          print "ctcp userinfo from $who\n";
          $kernel->post( $server => ctcpreply =>
                         $who, "USERINFO $conf{cuinfo}"
                       );
        },

        irc_ctcp_action => sub {
          my ($kernel, $sender, $where, $msg) = @_[KERNEL, ARG0..ARG2];
          my $who = (split /!/, $sender)[0];
          my $where =  $where->[0];
          print "<$who:$where> $msg\n";

          my $msg = "$who $msg";
          my $response = try_all($msg, $server, "act", $who, 1);
        },

        irc_invite => sub {
          my ($kernel, $who, $where) = @_[KERNEL, ARG0, ARG1];
          $kernel->yield( join => $where );
        },

        irc_kick => sub {
          my ($kernel, $who, $where, $isitme, $reason) =
            @_[KERNEL, ARG0..ARG4];
          print "$who was kicked from $where: $reason\n";
        },

        irc_disconnected => sub {
          my ($kernel, $server) = @_[KERNEL, ARG0];
          print "Lost connection to server $server.\n";
          $kernel->delay( connect => 60 );
        },

        irc_error => sub {
          my ($kernel, $error) = @_[KERNEL, ARG0];
          print "Server error occurred: $error\n";
          $kernel->delay( connect => 60 );
        },

        irc_socketerr => sub {
          my ($kernel, $error) = @_[KERNEL, ARG0];
          print "IRC client ($server): socket error occurred: $error\n";
          $kernel->delay( connect => 60 );
        },

        irc_public => sub {
          my ($kernel, $heap, $who, $where, $msg) =
            @_[KERNEL, HEAP, ARG0..ARG2];
          $who = (split /!/, $who)[0];
          $where = $where->[0];
          print "<$who:$where> $msg\n";

          $heap->{seen_traffic} = 1;

          # Ignore certain users.
          return if exists $ignored{lc $who};

          # Ignore if we aren't addressed.
          my $self = $conf{nick};
          my $addressed = 0;
          $addressed = 1 if $msg =~ s/^\s*$self[\#\)\-\:\>\}\|\,]+\s*//;

          # Do something with input here?
          my $response = try_all($msg, $server, $where, $who, $addressed);
          if (defined $response) {
            if (ref($response) eq "ARRAY") {
              foreach (@$response) {
                $kernel->post($server => privmsg => $where, $_);
              }
            }
            else {
              $kernel->post($server => privmsg => $where, $response);
            }
          }
        },
      }
    );
}

### Helper function.  Display a number of seconds as a formatted
### period of time.  NOT A POE EVENT HANDLER.

sub format_elapsed {
  my ($secs, $precision) = @_;
  my @fields;

  # If the elapsed time can be measured in weeks.
  if (my $part = int($secs / 604800)) {
    $secs %= 604800;
    push(@fields, $part . 'w');
  }

  # If the remaining time can be measured in days.
  if (my $part = int($secs / 86400)) {
    $secs %= 86400;
    push(@fields, $part . 'd');
  }

  # If the remaining time can be measured in hours.
  if (my $part = int($secs / 3600)) {
    $secs %= 3600;
    push(@fields, $part . 'h');
  }

  # If the remaining time can be measured in minutes.
  if (my $part = int($secs / 60)) {
    $secs %= 60;
    push(@fields, $part . 'm');
  }

  # If there are any seconds remaining, or the time is nothing.
  if ($secs || !@fields) {
    push(@fields, $secs . 's');
  }

  # Reduce precision, if requested.
  pop(@fields) while $precision and @fields > $precision;

  # Combine the parts.
  join(' ', @fields);
}

### Do the help stuff.  Used for public and private messages.
sub try_help {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless $msg =~ /^help(?:\s+(\w+))?$/;
  my $what = $1;
  $what = "help" unless $what;

  return $helptext{$what} if exists $helptext{$what};
  return "There's no help for topic '$what'.";
}

### Generate uptime message.
sub try_uptime {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless $msg =~ /^\s*uptime\s*$/;

  my ($user_time, $system_time) = (times())[0,1];
  my $wall_time = (time() - $^T) || 1;
  my $load_average = sprintf("%.4f", ($user_time+$system_time) / $wall_time);
  my $response =
    ( "I was started on " . scalar(gmtime($^T)) . " GMT. " .
      "I've been active for " . format_elapsed($wall_time, 2) . ". " .
      sprintf( "I have used about %.2f%% of a CPU during my lifespan.",
               (($user_time+$system_time)/$wall_time) * 100
             )
    );
}

### Helper.  Process a list of commands.
sub try_all {
  my ($msg, $net, $channel, $nick, $addressed) = @_;
  my $response;

  # Clean up input.
  $msg =~ s/\s+/ /g;
  $msg =~ s/^\s+//;
  $msg =~ s/\s+$//;

  $channel = "private" unless $channel;

  # Try things.
  $response = try_uptime($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_help($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_node($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_relate($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_complete($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_count($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  $response = try_status($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  # This goes last.

  $response = try_random_input($msg, $net, $channel, $nick, $addressed);
  return $response if defined $response;

  return;
}

###############################################################################
###############################################################################
# Custom stuff here.

sub init_bot {
  Util::Database::connect("dbi:Pg:dbname=troc", "", "");
}

### Try the node command.

sub try_node {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless $msg =~ /^\@node (.+?)$/;
  my $description = $1;

  my $node_id = Util::Database::store_node($description);
  return "Node $node_id = $description";
}

### Force a relation.

sub try_relate {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless
    $msg =~ /^\@rel(?:ate|ation)? \((.+?)\) \((.+?)\) \((.+?)\)\s*$/;
  my ($subject, $verb, $pred) = ($1, $2, $3);

  my $rel_id = Util::Database::store_relation($subject, $verb, $pred);

  return "Relation $rel_id = ($subject) ($verb) ($pred)\n";
}

### Display database statistics.

sub try_status {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless $msg =~ /^\@stat(us|s)$/;

  my $node_count = Util::Database::count_all_nodes() || "some";
  my $relation_count = Util::Database::count_all_relations() || "many";

  return( "I know of $node_count things.  " .
          "They are combined in $relation_count different ways."
        );
}

### Attempt to fill in the blanks on a relationship.

sub try_complete {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless
    $msg =~ /^\@(?:finish|complete|fill|find) \((.*?)\) \((.*?)\) \((.*?)\)/;
  my ($sub_str, $vrb_str, $prd_str) = ($1, $2, $3);

  $sub_str = undef if $sub_str =~ /^\s*$/;
  $vrb_str = undef if $vrb_str =~ /^\s*$/;
  $prd_str = undef if $prd_str =~ /^\s*$/;

  my $wild_count = 0;
  $wild_count++ unless defined $sub_str;
  $wild_count++ unless defined $vrb_str;
  $wild_count++ unless defined $prd_str;

  my $limit = 4;
  $limit = 32 if $channel eq "private";

  unless (defined($sub_str) or defined($vrb_str) or defined($prd_str)) {
    return "Please don't do that.";
  }

  my $result =
    Util::Database::find_nodes($sub_str, $vrb_str, $prd_str, $limit);

  return "Nothing returned." unless @{$result};
  return $result;
}

sub try_count {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  return undef unless
    $msg =~ /^\@count \((.*?)\) \((.*?)\) \((.*?)\)/;
  my ($sub_str, $vrb_str, $prd_str) = ($1, $2, $3);

  $sub_str = undef if $sub_str =~ /^\s*$/;
  $vrb_str = undef if $vrb_str =~ /^\s*$/;
  $prd_str = undef if $prd_str =~ /^\s*$/;

  my $count = Util::Database::count_relations($sub_str, $vrb_str, $prd_str);

  my $return;
  if ($count) {
    $return = "Your query matched $count factoid";
    $return .= "s" unless $count == 1;
  }
  else {
    $return = "Your query matched nothing.";
  }

  return $return;
}

sub try_random_input {
  my ($msg, $net, $channel, $nick, $addressed) = @_;

  # Ignore other commands.
  return undef if $msg =~ /^\@/;

  # Scan the sentence for the largest verb.
  my @words = split /\s+/, $msg;

  if (@words < 3) {
    return "That must be at least three words." if $addressed;
    return undef;
  }

  my $longest_verb = "";
  my $longest_length = 0;
  my $verb_phrase_start = 0;
  my $verb_phrase_end = -1;

  my $last_word = @words -1;
  for (my $start = 1; $start < $last_word; $start++) {
    for (my $end = $start; $end < $last_word; $end++) {
      my $phrase = join " ", @words[$start..$end];

      if (Util::Database::is_a_type_of_verb($phrase)) {
        if ($end - $start + 1 > $longest_length) {
          $longest_verb      = $phrase;
          $longest_length    = $end - $start + 1;
          $verb_phrase_start = $start;
          $verb_phrase_end   = $end;
        }
      }
    }
  }

  if ($longest_length) {
    my $subject = join(" ", @words[0..($verb_phrase_start-1)]);
    my $verb    = join(" ", @words[$verb_phrase_start..$verb_phrase_end]);
    my $pred    = join(" ", @words[($verb_phrase_end+1)..$#words]);

    my $rel_id = Util::Database::store_relation($subject, $verb, $pred);

    return "Relation $rel_id = ($subject) ($verb) ($pred)\n" if $addressed;
  }

  return "Couldn't find a verb in that." if $addressed;
  return undef;
}

#------------------------------------------------------------------------------
1;
