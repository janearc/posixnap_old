# $Id$

package Db;

use warnings;
use strict;
use DBI;

my $dbh;
my (
  $sth_node_add,
);

sub node_add {
  my ($class, $label) = @_;

  "currval('know_node_seq_seq')";   # <-- DTRT WRT SELECT

  # Attempt the insert.
  # Build a node object with it.
  # Return the node object.
}

sub node_get_by_label {
  my ($class, $label) = @_;

  # Select on the label.
  # Return a node.
}

sub node_get_by_id {
  my ($class, $node_id) = @_;

  # Select on ID.
  # Return a node.
}

sub node_get_by_arc_id {
  my ($class, $arc_id) = @_;

  # Select an arc id.
  # Return a node.
}

sub arc_find {
  my ($class, $sub_id, $prd_id, $obj_id) = @_;

  # Search for arcs that match.
  # Return a list of arc objects.
}

sub arc_add {
  my ($class, $sub_id, $prd_id, $obj_id) = @_;

  # Add an arc.
  # Return an arc object.
}

sub arc_count {
  my ($class, $sub_id, $prd_id, $obj_id) = @_;

  # Count arcs that match.
  # Return a count.
}

sub arc_add_anchor {
  # Add an 0,0,0 arc.
  # Return an Arc object built with it.
}

# Blow away the current triplet tables, and create new ones.  As an
# interesting constraint, we'll only allow one node per anchor arc.

sub rebuild {

  # Nodes.
  $dbh->do("DROP TABLE know_node");
  $dbh->do("DROP SEQUENCE know_node_seq_seq");
  $dbh->do("CREATE SEQUENCE know_node_seq_seq");
  $dbh->do(
    <<'    END'
      CREATE TABLE know_node (
        seq INTEGER DEFAULT nextval('know_node_seq_seq') NOT NULL,
        arc_seq INTEGER NOT NULL,
        value CHARACTER VARYING NOT NULL
      )
    END
  );
  $dbh->do(
    <<'    END'
      CREATE UNIQUE INDEX know_node_seq ON know_node USING BTREE (seq)
    END
  );
  $dbh->do(
    <<'    END'
      CREATE INDEX know_node_arc ON know_node USING BTREE (arc_seq)
    END
  );
  $dbh->do(
    <<'    END'
      CREATE UNIQUE INDEX know_node_value ON know_node USING BTREE (value)
    END
  );

  # Arcs.
  $dbh->do("DROP TABLE know_arc");
  $dbh->do("DROP SEQUENCE know_arc_seq_seq");
  $dbh->do("CREATE SEQUENCE know_arc_seq_seq");
  $dbh->do(
    <<'    END'
      CREATE TABLE know_arc (
        seq INTEGER DEFAULT nextval('know_arc_seq_seq') NOT NULL,
        sub_seq INTEGER NOT NULL,
        prd_seq INTEGER NOT NULL,
        obj_seq INTEGER NOT NULL
      )
    END
  );
  $dbh->do(
    <<'    END'
      CREATE UNIQUE INDEX know_arc_seq ON know_arc USING BTREE (seq)
    END
  );
  $dbh->do(
    <<'    END'
      CREATE INDEX know_arc_sub_seq ON know_arc USING BTREE (sub_seq)
    END
  );
  $dbh->do(
    <<'    END'
      CREATE INDEX know_arc_prd_seq ON know_arc USING BTREE (prd_seq)
    END
  );
  $dbh->do(
    <<'    END'
      CREATE INDEX know_arc_obj_seq ON know_arc USING BTREE (obj_seq)
    END
  );
}

# Open the database.  First thing necessary, always.

sub open {
  my $class = shift;
  $dbh = DBI->connect(@_);
  die "Could not connect to database: ", $dbh->errstr() if $dbh->err();
}

# Ensure that the database handle is properly closed.

END {
  $dbh->disconnect() if defined $dbh;
  undef $dbh;
}

1;
