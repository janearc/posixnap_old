# $Id$

package Db::Node;

use warnings;
use strict;

sub MY_SEQ     () { 0 }
sub MY_ARC_SEQ () { 1 }
sub MY_VAL     () { 2 }

sub new {
  my ($class, $value) = @_;

  # Try to fetch the entity.  Return an object to represent it if we
  # were successful.
  my ($seq, $arc_seq, $val) = Db->fetch_entity_by_value($value);
  if ($seq) {
    return bless [
      $seq,      # MY_SEQ
      $arc_seq,  # MY_ARC_SEQ
      $val,      # MY_VAL
    ], $class;
  }

  # Try to create an empty arc record to act as an anchor point for
  # the entity.  Die if this fails.
  my $arc = Db::Arc->new(0, 0, 0);

  $arc_seq = Db->create_empty_arc();
  die unless defined $arc_seq;

  # Create a new entity record, pointing to the new anchor arc.
  # Return an object to represent it.
  my $seq = Db->create_new_entity($arc_seq, $value);
  return bless [
    $seq,      # MY_SEQ
    $arc_seq,  # MY_ARC_SEQ
    $val,      # MY_VAL
  ], $class;
}

sub seq     { return shift()->[MY_SEQ];     }
sub arc_seq { return shift()->[MY_ARC_SEQ]; }
sub val     { return shift()->[MY_VAL];     }

1;
