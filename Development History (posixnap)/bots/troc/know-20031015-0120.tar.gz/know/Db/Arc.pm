# $Id$

package Db::Arc;

use warnings;
use strict;

sub MY_SEQ     () { 0 }
sub MY_SUB_SEQ () { 1 }
sub MY_PRD_SEQ () { 2 }
sub MY_OBJ_SEQ () { 3 }

sub new {
  my ($class, $sub_seq, $prd_seq, $obj_seq) = @_;

  # Try to fetch the arc.  Return an object to represent it if we were
  # successful.
  my $seq = Db->fetch_arc_seq_by_values($sub_seq, $prd_seq, $obj_seq);
  if ($seq) {
    return bless [
      $seq,      # MY_SEQ
      $sub_seq,  # MY_SUB_SEQ
      $prd_seq,  # MY_PRD_SEQ
      $obj_seq,  # MY_OBJ_SEQ
    ], $class;
  }

  # Create a new arc for the triplet.
  $seq = Db->create_new_arc($sub_seq, $prd_seq, $obj_seq);
  die unless defined $seq;

  # Create a new arc object based on it.
  return bless [
    $seq,      # MY_SEQ
    $sub_seq,  # MY_SUB_SEQ
    $prd_seq,  # MY_PRD_SEQ
    $obj_seq,  # MY_OBJ_SEQ
  ], $class;
}

sub seq     { return shift()->[MY_SEQ];     }
sub sub_seq { return shift()->[MY_SUB_SEQ]; }
sub prd_seq { return shift()->[MY_PRD_SEQ]; }
sub obj_seq { return shift()->[MY_OBJ_SEQ]; }

1;
