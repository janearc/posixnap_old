# $Id: IRC.pm,v 1.3 2002/10/18 02:44:48 rcaputo Exp $

package SQL::Postgres;

*{'SQL::'} = \*{__PACKAGE__ . '::'};

use strict;
use warnings;

use constant COUNT_ALL_NODES => "SELECT count(seq) FROM node";
use constant COUNT_ALL_RELATIONS => "SELECT count(seq) FROM relation";
use constant FETCH_NODE_ID => "SELECT seq FROM node WHERE description = ?";
use constant STORE_NODE => "INSERT INTO node (description) VALUES (?)";
use constant FETCH_NODE_DESCRIPTION =>
  "SELECT description FROM node WHERE id = ?";
use constant FETCH_RELATION =>
  "SELECT seq FROM relation WHERE subseq = ? AND vrbseq = ? AND prdseq = ?";
use constant STORE_RELATION =>
  "INSERT INTO relation (subseq, vrbseq, prdseq) VALUES (?, ?, ?)";

use constant COUNT_NODES => sub {
  my($sub_str, $vrb_str, $prd_str) = @_;

  my $query =
    ( "SELECT count(t3.seq) FROM node t0, node t1, node t2, " .
      "relation t3 WHERE (t0.seq = t3.subseq) and " .
      "(t1.seq = t3.vrbseq) and (t2.seq = t3.prdseq) "
    );

  my (@parameters, @wheres);

  if (defined $sub_str) {
    push @parameters, $sub_str;
    push @wheres, "(t0.description = ?)";
  }

  if (defined $vrb_str) {
    push @parameters, $vrb_str;
    push @wheres, "(t1.description = ?)";
  }

  if (defined $prd_str) {
    push @parameters, $prd_str;
    push @wheres, "(t2.description = ?)";
  }

  if (@wheres) {
    $query .= "and " . join(" and ", @wheres);
  }

  return ($query, @parameters);
};

use constant FIND_NODES => sub {
  my($sub_str, $vrb_str, $prd_str, $limit) = @_;

  my $query =
    ( "SELECT t0.description as subject, t1.description as verb, " .
      "t2.description as predicate FROM node t0, node t1, node t2, " .
      "relation t3 WHERE (t0.seq = t3.subseq) and " .
      "(t1.seq = t3.vrbseq) and (t2.seq = t3.prdseq) "
    );

  my (@parameters, @wheres);

  if (defined $sub_str) {
    push @parameters, $sub_str;
    push @wheres, "(t0.description = ?)";
  }

  if (defined $vrb_str) {
    push @parameters, $vrb_str;
    push @wheres, "(t1.description = ?)";
  }

  if (defined $prd_str) {
    push @parameters, $prd_str;
    push @wheres, "(t2.description = ?)";
  }

  if (@wheres) {
    $query .= "and " . join(" and ", @wheres);
  }

  $query .= " ORDER BY subject asc, verb asc, predicate asc";

  if ($limit) {
    $query .= " LIMIT $limit";
  }

  return ($query, @parameters);
};

use constant FIND_NODES_BY_ID => sub {
  my($sub_id, $vrb_id, $prd_id) = @_;

  my $query =
    ( "SELECT t0.description as subject, t1.description as verb, " .
      "t2.description as predicate FROM node t0, node t1, node t2, " .
      "relation t3 WHERE (t0.seq = t3.subseq) and " .
      "(t1.seq = t3.vrbseq) and (t2.seq = t3.prdseq) "
    );

  my (@parameters, @wheres);

  if (defined $sub_id) {
    push @parameters, $sub_id;
    push @wheres, "(t0.seq = ?)";
  }

  if (defined $vrb_id) {
    push @parameters, $vrb_id;
    push @wheres, "(t1.seq = ?)";
  }

  if (defined $prd_id) {
    push @parameters, $prd_id;
    push @wheres, "(t2.seq = ?)";
  }

  if (@wheres) {
    $query .= "and " . join(" and ", @wheres);
  }

  $query .= " ORDER BY subject asc, verb asc, predicate asc";

  return ($query, @parameters);
};

1;
