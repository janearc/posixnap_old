# $Id: IRC.pm,v 1.3 2002/10/18 02:44:48 rcaputo Exp $

package Util::Database;

use strict;
use warnings;

use DBI;

use SQL::Postgres;

use constant ITERATOR_FIND_NODES => sub {
    # (subj) (verb) (pred)
    return "($_[0]) ($_[1]) ($_[2])";
};

use constant ITERATOR_FIND_SUBJECTS => sub {
  return $_[0];
};

### Connect to the database.
my $dbh;
END { $dbh->disconnect() if defined $dbh; }

sub connect ($$$) {
    $dbh = DBI->connect(@_);
    die("Could not connect to database: ", $dbh->errstr) if $dbh->err;
    return $dbh;
}

sub count ($;@) {
  my $sth = $dbh->prepare_cached(shift);
  $sth->execute(@_) or die $sth->errstr;
  my @row = $sth->fetchrow_array();
  $sth->finish();
  return $row[0];
}

sub iterate_rows ($$;@) {
  my $sth = $dbh->prepare_cached(shift);
  my $iterator = shift;
  $sth->execute(@_) or die $sth->errstr;

  my @returns;
  while (my @row = $sth->fetchrow_array()) {
    push @returns, $iterator->(@row);
  }

  $sth->finish();

  return \@returns;
}

use Carp qw(confess);

sub fetch_row {
  my $sth = $dbh->prepare_cached(shift);
  $sth->execute(@_) or confess $sth->errstr;

  my @row = $sth->fetchrow_array();

  $sth->finish();

  return \@row;
}

sub fetch_column {
  my $column = shift;
  return fetch_row(@_)->[$column];
}

sub execute {
  my $sth = $dbh->prepare(shift);
  $sth->execute(@_) or die $sth->errstr;
  $sth->finish();
}

sub count_all_relations {
  return count(SQL::COUNT_ALL_RELATIONS());
}

sub count_all_nodes {
  return count(SQL::COUNT_ALL_NODES());
}

sub count_relations {
  my($sub_str, $vrb_str, $prd_str) = @_;
  my($query, @parameters) = SQL::COUNT_NODES->($sub_str, $vrb_str, $prd_str);
  return count($query, @parameters);
}

sub find_nodes {
  my($sub_str, $vrb_str, $prd_str, $limit) = @_;
  my($query, @parameters) =
    SQL::FIND_NODES->($sub_str, $vrb_str, $prd_str, $limit);
  return iterate_rows($query, ITERATOR_FIND_NODES, @parameters);
}

sub fetch_node_id {
  return fetch_column
    ( 0,
      SQL::FETCH_NODE_ID,
      shift
    );
}

sub fetch_node_description {
  return fetch_column
    ( 0,
      SQL::FETCH_NODE_DESCRIPTION,
      shift
    );
}

sub store_node {
  my $description = shift;

  my $node_id = fetch_node_id($description);
  return $node_id if defined $node_id;

  execute(SQL::STORE_NODE, $description);

  return fetch_node_id($description);
}

sub fetch_relation {
  my ($subject_id, $verb_id, $predicate_id) = @_;

  return undef unless defined $subject_id   and length $subject_id;
  return undef unless defined $verb_id      and length $verb_id;
  return undef unless defined $predicate_id and length $predicate_id;

  return fetch_column
    ( 0,
      SQL::FETCH_RELATION,
      $subject_id, $verb_id, $predicate_id
    );
}

my $master_verb_id;    # ID of special "verb" node.
my $master_type_of_id; # ID of special "is a type of" node.
my %verbs;             # cache of known verbs

sub check_master_ids {
  $master_type_of_id = fetch_node_id("is a type of")
    unless defined $master_type_of_id;

  $master_verb_id = fetch_node_id("verb")
    unless defined $master_verb_id;

  unless (%verbs) {
    my($query, @parameters) =
      SQL::FIND_NODES_BY_ID->(undef, $master_type_of_id, $master_verb_id);

    my $verb_phrases =
      iterate_rows($query, ITERATOR_FIND_SUBJECTS, @parameters);

    foreach (@$verb_phrases) {
      $verbs{$_} = 1;
    }
  }
}

sub store_relation {
  my ($subject, $verb, $predicate) = @_;

  my $subject_id   = Util::Database::store_node($subject);
  my $verb_id      = Util::Database::store_node($verb);
  my $predicate_id = Util::Database::store_node($predicate);

  my $relation_id = fetch_relation($subject_id, $verb_id, $predicate_id);
  return $relation_id if defined $relation_id;

  execute
    ( SQL::STORE_RELATION,
      $subject_id, $verb_id, $predicate_id,
    );

  check_master_ids();
  if ($verb_id == $master_type_of_id and $predicate_id == $master_verb_id) {
    $verbs{$subject} = 1;
  }

  return fetch_relation($subject_id, $verb_id, $predicate_id);
}

sub is_a_type_of_verb {
  my $phrase = shift;

  check_master_ids();
  return unless $master_type_of_id and $master_verb_id;

  return exists $verbs{$phrase};
}

1;

