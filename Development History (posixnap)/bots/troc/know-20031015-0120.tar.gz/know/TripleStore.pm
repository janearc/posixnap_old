# $Id$

package TripleStore;

use warnings;
use strict;

use DBI;

# Static database handle, shared by all instances.
my $dbh;

# Attempt to ensure a clean disconnection.
END { $dbh->disconnect() if defined $dbh }

sub new {
  my $class = shift;
  my $self = bless [], $class;
  return $self;
}
