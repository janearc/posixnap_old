# $Id$

# Common bot backend things.

package Util::Common;

use warnings;
use strict;
use Exporter;

use base qw(Exporter);
use vars qw(@EXPORT_OK);
@EXPORT_OK = qw(
  try_uptime break_into_sentences
);

### Split an utterance into sentences.

sub break_into_sentences {
  my $text = shift;

  # Remove leading, trailing whitespace.
  $text =~ s/^\s+//;
  $text =~ s/\s+$//;

  # Remove mIRC colors and control characters.
  $text =~ s/\x03\d+,?\d*//g;
  $text =~ tr[\x00-\x1f][]d;

  # Add sentence separators to the text.
  $text =~ s/(?<=[^\.\?\!][\.\?\!])\s+/\0/g;

  # Remove sentence separators that are after things that can't end
  # sentences.
  $text =~ s/(\b[a-z]\.)\0/$1 /ig;
  $text =~ s/(Mrs|Mr|Ms|Dr)\.\0/$1. /ig;
  $text =~ s/\<\?\0/<? /g;

  # Move sentence separators past strange punctuation.
  $text =~ s/\0([^a-zA-Z0-9]+)\s+/ $1\0/g;

  # Break into sentences already.
  my @sentences = split /\0/, $text;
}

### Generate uptime message.

sub try_uptime {
  my ($msg, $mode, $nick, $addressed) = @_;

  return undef unless $addressed or $mode eq "private";
  return undef unless $msg =~ /^\s*uptime\s*$/;

  my $name = $0;
  $name =~ s/.*[\/\\]//;  # Leading path.
  $name =~ s/\.[^\.]+$//; # Extension.

  my ($user_time, $system_time) = (times())[0,1];
  my $wall_time = (time() - $^T) || 1;
  my $load_average = sprintf("%.4f", ($user_time+$system_time) / $wall_time);
  my $response = (
    "$name (pid $$) started on " . scalar(gmtime($^T)) . " GMT.  " .
    "Uptime: " . format_elapsed($wall_time, 2) . ".  " .
    sprintf(
      "CPU load: %.2f%%.", (($user_time+$system_time)/$wall_time) * 100
    )
  );
}

### Helper function.  Display a number of seconds as a formatted
### period of time.  NOT A POE EVENT HANDLER.

sub format_elapsed {
  my ($secs, $precision) = @_;
  my @fields;

  # If the elapsed time can be measured in weeks.
  if (my $part = int($secs / 604800)) {
    $secs %= 604800;
    push(@fields, $part . 'w');
  }

  # If the remaining time can be measured in days.
  if (my $part = int($secs / 86400)) {
    $secs %= 86400;
    push(@fields, $part . 'd');
  }

  # If the remaining time can be measured in hours.
  if (my $part = int($secs / 3600)) {
    $secs %= 3600;
    push(@fields, $part . 'h');
  }

  # If the remaining time can be measured in minutes.
  if (my $part = int($secs / 60)) {
    $secs %= 60;
    push(@fields, $part . 'm');
  }

  # If there are any seconds remaining, or the time is nothing.
  if ($secs || !@fields) {
    push(@fields, $secs . 's');
  }

  # Reduce precision, if requested.
  pop(@fields) while $precision and @fields > $precision;

  # Combine the parts.
  join(' ', @fields);
}

1;
