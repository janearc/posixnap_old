# $Id$

package Server::Backends;

use warnings;
use strict;

use POE;
use POE::Filter::Reference;
use POE::Component::Server::TCP;

#use Util::Conf qw(SCALAR LIST REQUIRED);
#
#Util::Conf->associate_type_with_schema(
#  multiplexer => {
#    multiplexer => {
#      bind_interface => SCALAR,
#      bind_port      => SCALAR | REQUIRED,
#    }
#  }
#);
#
#my $conf = Util::Conf->read("./multiplexer.conf", "multiplexer");

my %backends;

POE::Component::Server::TCP->new(
  Port               => 12345,
  ClientFilter       => 'POE::Filter::Reference',
  ClientConnected    => \&handle_client_connect,
  ClientDisconnected => \&handle_client_disconnect,
  ClientError        => \&handle_client_error,
  ClientInput        => \&handle_client_input,
  InlineStates => {
    send             => \&do_send_request,
  },
);

# Class method.
sub send {
  my ($class, $request) = @_;
  foreach my $backend_client_id (keys %backends) {
    $request->{ts10svrbcst} = time();
    $poe_kernel->post($backend_client_id => send => $request);
  }
}

# Remainder are POE handlers for backend client sessions.

sub handle_client_connect {
  my $session_id = $_[SESSION]->ID;
  $backends{$session_id} = 1;
}

sub handle_client_disconnect {
  my $session_id = $_[SESSION]->ID;
  delete $backends{$session_id};
}

sub handle_client_error {
  my $session_id = $_[SESSION]->ID;
  delete $backends{$session_id};
  $_[KERNEL]->yield("shutdown");
}

sub handle_client_input {
  my ($kernel, $response) = @_[KERNEL, ARG0];
  $response->{ts50svrrecv} = time();

  return unless defined $response->network();
  my $bot = "irc_client_" . $response->network();

  $kernel->post($bot => backend_response => $response);
}

sub do_send_request {
  my ($heap, $request) = @_[HEAP, ARG0];
  return unless $heap->{client};
  $request->{ts20svrsend} = time();
  $heap->{client}->put($request);
}

1;
