/*  This file can be automatically generated; changes may be lost.
**
**
**  CursesTyp.c -- typedef handlers
**
**  Copyright (c) 1994-2001  William Setzer
**
**  You may distribute under the terms of either the Artistic License
**  or the GNU General Public License, as specified in the README file.
*/

#ifndef C_TYPATTR_T
#define attr_t int
#endif

#ifndef C_TYPBOOL
#define bool int
#endif

#ifndef C_TYPCHTYPE
#define chtype int
#endif

#ifndef C_TYPMEVENT
#define MEVENT int
#endif

#ifndef C_TYPMMASK_T
#define mmask_t int
#endif

#ifndef C_TYPSCREEN
#define SCREEN int
#endif

