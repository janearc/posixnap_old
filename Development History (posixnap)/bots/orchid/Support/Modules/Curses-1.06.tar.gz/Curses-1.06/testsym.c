#include "c-config.h"

main() {
  SYM;
}
