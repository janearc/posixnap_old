package WWW::Search::Result;

use WWW::SearchResult;

@ISA = qw( WWW::SearchResult );

1;
