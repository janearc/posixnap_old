
use strict;

package WWW::Scraper::Opcode::TD;
use base qw(WWW::Scraper::Opcode);


1;
