
use strict;

package WWW::Scraper::Opcode::FONT;
use base qw(WWW::Scraper::Opcode);

sub scrape { shift->SUPER::scrape(@_) }
1;
