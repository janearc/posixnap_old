#!/usr/local/bin/perl

use Geo::WeatherNOAA;

print print_current('newport news','va');
print print_forecast('newport news','va');
