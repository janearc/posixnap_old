#!/usr/local/bin/perl

use Geo::WeatherNOAA;

print "Geo::WeatherNOAA.pm v.$Geo::WeatherNOAA::VERSION\n";

print print_current('newport news','va');
