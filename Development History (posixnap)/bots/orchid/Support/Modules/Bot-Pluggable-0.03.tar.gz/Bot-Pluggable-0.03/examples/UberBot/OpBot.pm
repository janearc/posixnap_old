
package UberBot::OpBot;
use strict;
use POE;

sub new {
    my $class = shift;
    return bless {}, $class;
}

1;